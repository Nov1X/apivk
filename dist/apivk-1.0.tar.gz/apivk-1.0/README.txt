apivk MODULE
============
A VK API library.